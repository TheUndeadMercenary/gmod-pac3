player_manager.AddValidModel( "Grunt", "models/gruntv2/gruntV2.mdl" );
player_manager.AddValidHands( "Grunt", "models/gruntv2/gruntV2_c_hands.mdl", 0, "0000000" )