CreateConVar( "sv_hurtsounds", "1", { FCVAR_REPLICATED, FCVAR_NOTIFY } ) --Incase you find it annoying somehow you can always disable it with "sv_hurtsounds"
CreateConVar( "sv_viewheight", "1", { FCVAR_REPLICATED, FCVAR_NOTIFY } ) --Incase you find it annoying somehow you can always disable it with "sv_hurtsounds"


local function GruntSPDeathSounds(ply)
	if GetConVarNumber( "sv_hurtsounds" ) == 1 then
	
	if (ply:GetModel() == "models/gruntv2/grunt.mdl") then
		ply:EmitSound("dialog/grunt/death" .. math.random( 1 ) .. ".wav") 
	end

	end
end
hook.Add( "DoPlayerDeath", "GruntSPDeathSounds", GruntSPDeathSounds )

grunt_hurt_spam = false
local function GruntSPHurtSounds(ply)
	if GetConVarNumber( "sv_hurtsounds" ) == 1 then
	if ply:Health() == 0 then return end
	if grunt_hurt_spam == true then return end

	grunt_hurt_spam = true
	timer.Create( "GruntSPPly_SVD4_"..ply:SteamID(), 1, 1, function()
	grunt_hurt_spam = false
	end)

	if (ply:GetModel() == "models/gruntv2/grunt.mdl") then
	ply:EmitSound("dialog/grunt/hurt" .. math.random( 1, 4 ) .. ".wav")
	end


	end
end
hook.Add( "PlayerHurt", "GruntSPHurtSounds", GruntSPHurtSounds )
