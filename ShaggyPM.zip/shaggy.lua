player_manager.AddValidModel( "Shaggy Rogers", "models/shaggypm/shaggypm.mdl" )
player_manager.AddValidHands( "Shaggy Rogers", "models/viewmodel/arms/c_arm_shaggy.mdl", 0, "00000000" )
list.Set( "PlayerOptionsModel",	"Shaggy Rogers", "models/shaggypm/shaggypm.mdl" )

